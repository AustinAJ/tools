/* */ 
module.exports = require('./collapse/index');
