/* */ 
module.exports = require('./accordion/index');
