/* */ 
module.exports = { "default": require("core-js/library/fn/array/shift"), __esModule: true };