/* */ 
require('../position/index-nocss');
require('./dropdown');
var MODULE_NAME = 'ui.bootstrap.module.dropdown';
angular.module(MODULE_NAME, ['ui.bootstrap.dropdown']);
module.exports = MODULE_NAME;
