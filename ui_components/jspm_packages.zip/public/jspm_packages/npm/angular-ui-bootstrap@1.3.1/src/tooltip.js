/* */ 
module.exports = require('./tooltip/index');
