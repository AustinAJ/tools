/* */ 
module.exports = require('./pager/index');
