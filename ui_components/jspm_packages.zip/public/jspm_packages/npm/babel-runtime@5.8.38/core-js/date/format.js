/* */ 
module.exports = { "default": require("core-js/library/fn/date/format"), __esModule: true };