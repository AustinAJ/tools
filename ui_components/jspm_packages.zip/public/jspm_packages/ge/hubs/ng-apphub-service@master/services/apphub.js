
const GLOBAL_KEY = "_apphub";
const STATE_KEY = 'state';
const locations = ['main', 'settings', 'profile'];

/**
 * @ngdoc service
 * @name AppHubModule.service:AppHubService
 * @author j.defrisco@ge.com
 * @memberOf AppHubModule
 * @description AppHub convenience methods
 */
class AppHubService {

    constructor($window){
        this.$window = $window;
    }

    /**
     * @ngdoc
     * @name AppHubService#getPath
     * @methodOf AppHubModule.service:AppHubService
     * @description
     * Given a microapp id, get the path to the microapp
     * If no id is supplied, returns the path to the current microapp
     * @example
     * ```
     * let url = apphub.getPath('analytics');
     * ```
     */
    getPath(uappId) {
        let id = uappId ? uappId : this.getCurrentApp();
        return  this.$window.nav && this.$window.nav.paths[id] ? this.$window.nav.paths[id] : this.getContext();
    }

    /**
     * @ngdoc
     * @name AppHubService#getCurrentApp
     * @methodOf AppHubModule.service:AppHubService
     * @description
     * Return the id of the current microapp
     * @example
     * ```
     * let url = apphub.getPath(apphub.getCurrentApp());
     * ```
     */
    getCurrentApp() {
        var id;
        let curPath = this.$window.location.pathname;  // this is how they appear in window.nav
        let navItems = this.$window.nav && this.$window.nav.paths ? this.$window.nav.paths : {};

        for(let key in this.$window.nav){
            if(this.$window.nav.hasOwnProperty(key) && locations.indexOf(key) !== -1){

                let region = this.$window.nav[key];
                for (let i = 0, len = region.items.length; i < len; i++) {
                    let item = region.items[i];
                    let nextId = item.id.substring(0,item.id.lastIndexOf('.'));
                    if(navItems.hasOwnProperty(nextId) && navItems[nextId] + '/' === curPath ){
                        id = nextId;
                        break;
                    }
                }
                if(id){
                    break;
                }
            }
        }
        return id ? id : null;
    }

    /**
     * @ngdoc
     * @name AppHubService#setState
     * @methodOf AppHubModule.service:AppHubService
     * @description
     * Save some global (cross micro-app) state to local storage. Merges passed object with current state.
     * @param {Object} value - an object holding the state to save
     * @example
     * ```
     * apphub.setState(value);
     * ```
     */
    setState(value) {
        // require an object here
        if (typeof value == 'object') {
            let curState = this.getLocalStore(STATE_KEY, GLOBAL_KEY);
            // merge in new state
            for (let p in value) {
                if (value.hasOwnProperty(p)) {
                    curState[p] = value[p];
                }
            }
            this.setLocalStore(STATE_KEY, curState, GLOBAL_KEY);
        } else {
            console.error('setState() called without an object to store');
        }
    }

    /**
     * @ngdoc
     * @name AppHubService#getState
     * @methodOf AppHubModule.service:AppHubService
     * @description
     * Retrieve the global (cross-microapp) state from local storage.
     * @returns {Object} - if there is no local storage associated with the passed key, an empty object is returned.
     * @example
     * ```
     * let curState = apphub.getState();
     * ```
     */
    getState() {
        return this.getLocalStore(STATE_KEY, GLOBAL_KEY);
    }

    /**
     * @ngdoc
     * @name AppHubService#setLocalStore
     * @methodOf AppHubModule.service:AppHubService
     * @description
     * Save some app-specific info to local storage
     * @param {string} key - the key used to store/retrieve the value
     * @param {Object} value - an object holding the value to save
     * @param {string=} appId - the appId to associate the key with. Defaults to the current microapp.
     * @example
     * ```
     * apphub.setLocalStore(key, value);
     * ```
     */
    setLocalStore(key, value, appId) {
        let k = (appId || this.getCurrentApp()) + ':' + key;
        this.$window.sessionStorage.setItem(k, JSON.stringify(value));
    }

    /**
     * @ngdoc
     * @name AppHubService#setLocalStore
     * @methodOf AppHubModule.service:AppHubService
     * @description
     * Get app-specific info from local storage. appId is optional - defaults to current app.
     * @param {string} key - the key used to store/retrieve the value
     * @param {string=} appId - the appId to associate the key with. Defaults to the current microapp.
     * @returns {Object} - if there is no local storage associated with the passed key, an empty object is returned.
     * @example
     * ```
     * let myvalue = apphub.getLocalStore('prefs');
     * ```
     */
    getLocalStore(key, appId) {
        let app = appId || this.getCurrentApp();
        let v = this.$window.sessionStorage.getItem(app + ':' + key) || '{}';
        return JSON.parse(v);
    }

    /**
     * @ngdoc
     * @name AppHubService#appAvailable
     * @methodOf AppHubModule.service:AppHubService
     * @description
     * Return true if the app for the passed appId is accessible by the current user
     * @example
     * ```
     * let appAvailable = apphub.appAvailable('someMicroappId');
     * ```
     */
    appAvailable(uappId) {
        return this.getPath(uappId) != this.getContext();
    }
    // convenience function to get the current multi-tenant context
    getContext() {
        return this.$window.nav && this.$window.nav.contextPath ? this.$window.nav.contextPath : '';
    }


    static serviceFactory($window){
        return new AppHubService($window);
    }


}

// class constants

// Strict DI for minification (order is important)
AppHubService.serviceFactory.$inject = ['$window'];

// Export an instance
export default AppHubService.serviceFactory;
