/* */ 
module.exports = { "default": require("core-js/library/fn/clear-immediate"), __esModule: true };